"use client";

import { useEffect, useMemo, useState } from "react";
import Nav from "@/components/Nav";
import { getLang, t, type Lang } from "@/lib/i18n";
import { supabase } from "@/lib/supabase";
import type { Tournament } from "@/lib/types";
import { shuffle } from "@/lib/draw";

function getLangFromUrl(): Lang {
  const sp = new URLSearchParams(window.location.search);
  const lang = sp.get("lang");
  return lang === "en" ? "en" : "ar";
}

export default function AdminPage() {
  const [lang, setLang] = useState<Lang>("ar");
  const tr = t(lang);

  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState("");
  const [loginMsg, setLoginMsg] = useState<string | null>(null);

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(false);

  // create form
  const [name, setName] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [timeText, setTimeText] = useState("");
  const [daysText, setDaysText] = useState("");
  const [teamsCount, setTeamsCount] = useState(2);
  const [playersPerTeam, setPlayersPerTeam] = useState(4);
  const [createMsg, setCreateMsg] = useState<string | null>(null);

  useEffect(() => {
    setLang(getLangFromUrl());
    const v = localStorage.getItem("admin_ok");
    setAuthed(v === "1");
  }, []);

  const refresh = async () => {
    const { data } = await supabase.from("tournaments").select("*").order("created_at", { ascending: false }).limit(50);
    setTournaments((data ?? []) as Tournament[]);
  };

  useEffect(() => {
    refresh();
  }, []);

  const login = async () => {
    setLoginMsg(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        setLoginMsg(lang === "ar" ? "كلمة المرور غير صحيحة" : "Wrong password");
      } else {
        localStorage.setItem("admin_ok", "1");
        setAuthed(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("admin_ok");
    setAuthed(false);
  };

  const createTournament = async () => {
    setCreateMsg(null);
    setLoading(true);
    try {
      const { error } = await supabase.from("tournaments").insert({
        name: name.trim(),
        logo_url: logoUrl.trim() || null,
        start_date: startDate || null,
        end_date: endDate || null,
        time_text: timeText.trim() || null,
        days_text: daysText.trim() || null,
        teams_count: teamsCount,
        players_per_team: playersPerTeam,
        registration_open: true,
        draw_done: false,
      });
      if (error) setCreateMsg(error.message);
      else {
        setCreateMsg(lang === "ar" ? "تم إنشاء البطولة ✅" : "Tournament created ✅");
        setName(""); setLogoUrl(""); setStartDate(""); setEndDate(""); setTimeText(""); setDaysText("");
        await refresh();
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleRegistration = async (id: string, open: boolean) => {
    await supabase.from("tournaments").update({ registration_open: open }).eq("id", id);
    await refresh();
  };

  const runDraw = async (tourn: Tournament) => {
    setLoading(true);
    try {
      // fetch registrations
      const { data: regs, error: e1 } = await supabase
        .from("registrations")
        .select("*")
        .eq("tournament_id", tourn.id)
        .order("created_at", { ascending: true });

      if (e1) { alert(e1.message); return; }

      const registrations = (regs ?? []) as any[];
      const needed = tourn.teams_count * tourn.players_per_team;
      if (registrations.length < needed) {
        alert(`${tr.needMorePlayers}\n${lang==="ar" ? "المطلوب" : "Needed"}: ${needed} • ${lang==="ar" ? "المتوفر" : "Current"}: ${registrations.length}`);
        return;
      }

      // clear existing draw (MVP: delete and recreate)
      await supabase.from("draw_team_members").delete().in("team_id",
        (await supabase.from("draw_teams").select("id").eq("tournament_id", tourn.id)).data?.map((x:any)=>x.id) ?? []
      );
      await supabase.from("draw_teams").delete().eq("tournament_id", tourn.id);

      // create teams
      const teamsPayload = Array.from({ length: tourn.teams_count }).map((_, i) => ({ tournament_id: tourn.id, team_number: i + 1 }));
      const { data: newTeams, error: eTeams } = await supabase.from("draw_teams").insert(teamsPayload).select("*");
      if (eTeams) { alert(eTeams.message); return; }

      const shuffled = shuffle(registrations).slice(0, needed);

      // allocate
      const membersPayload: any[] = [];
      for (let i = 0; i < tourn.teams_count; i++) {
        const team = (newTeams ?? [])[i];
        const start = i * tourn.players_per_team;
        const chunk = shuffled.slice(start, start + tourn.players_per_team);
        for (const r of chunk) membersPayload.push({ team_id: team.id, registration_id: r.id });
      }

      const { error: eMem } = await supabase.from("draw_team_members").insert(membersPayload);
      if (eMem) { alert(eMem.message); return; }

      await supabase.from("tournaments").update({ draw_done: true, registration_open: false }).eq("id", tourn.id);
      alert(lang === "ar" ? "تمت القرعة ✅" : "Draw completed ✅");
      await refresh();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <Nav />

      {!authed ? (
        <div className="card" style={{maxWidth: 520}}>
          <h2 style={{marginTop: 0}}>{tr.admin}</h2>
          <div className="formRow">
            <div>
              <label className="muted">{tr.password}</label>
              <input className="input" value={password} onChange={(e) => setPassword(e.target.value)} type="password" />
            </div>
          </div>
          <div style={{display:"flex", gap:10, alignItems:"center", marginTop: 12}}>
            <button className="btn" onClick={login} disabled={loading || !password}>{loading ? "..." : tr.login}</button>
            {loginMsg && <span className="muted">{loginMsg}</span>}
          </div>
        </div>
      ) : (
        <>
          <div className="card">
            <div style={{display:"flex", justifyContent:"space-between", gap:10, alignItems:"center"}}>
              <h2 style={{margin: 0}}>{tr.createTournament}</h2>
              <button className="btn secondary" onClick={logout}>{tr.logout}</button>
            </div>

            <div className="sep" />

            <div className="formRow two">
              <div>
                <label className="muted">{lang==="ar" ? "اسم البطولة" : "Tournament name"}</label>
                <input className="input" value={name} onChange={(e)=>setName(e.target.value)} />
              </div>
              <div>
                <label className="muted">{lang==="ar" ? "رابط الشعار (اختياري)" : "Logo URL (optional)"}</label>
                <input className="input" value={logoUrl} onChange={(e)=>setLogoUrl(e.target.value)} placeholder="https://..." />
              </div>
            </div>

            <div className="formRow two" style={{marginTop: 10}}>
              <div>
                <label className="muted">{tr.startDate}</label>
                <input className="input" value={startDate} onChange={(e)=>setStartDate(e.target.value)} type="date" />
              </div>
              <div>
                <label className="muted">{tr.endDate}</label>
                <input className="input" value={endDate} onChange={(e)=>setEndDate(e.target.value)} type="date" />
              </div>
            </div>

            <div className="formRow two" style={{marginTop: 10}}>
              <div>
                <label className="muted">{tr.time}</label>
                <input className="input" value={timeText} onChange={(e)=>setTimeText(e.target.value)} placeholder={lang==="ar" ? "مثال: 9:00 مساءً" : "e.g. 9:00 PM"} />
              </div>
              <div>
                <label className="muted">{tr.days}</label>
                <input className="input" value={daysText} onChange={(e)=>setDaysText(e.target.value)} placeholder={lang==="ar" ? "مثال: الجمعة والسبت" : "e.g. Fri & Sat"} />
              </div>
            </div>

            <div className="formRow two" style={{marginTop: 10}}>
              <div>
                <label className="muted">{tr.teamsCount}</label>
                <input className="input" value={teamsCount} onChange={(e)=>setTeamsCount(Math.max(2, parseInt(e.target.value || "2", 10)))} type="number" min={2} />
              </div>
              <div>
                <label className="muted">{tr.playersPerTeam}</label>
                <input className="input" value={playersPerTeam} onChange={(e)=>setPlayersPerTeam(Math.max(1, parseInt(e.target.value || "1", 10)))} type="number" min={1} />
              </div>
            </div>

            <div style={{display:"flex", gap:10, alignItems:"center", marginTop: 12}}>
              <button className="btn" onClick={createTournament} disabled={loading || !name.trim()}>
                {loading ? "..." : (lang==="ar" ? "حفظ" : "Save")}
              </button>
              {createMsg && <span className="muted">{createMsg}</span>}
            </div>
          </div>

          <h2 style={{margin: "22px 0 10px"}}>{lang==="ar" ? "إدارة البطولات" : "Manage tournaments"}</h2>

          <div className="grid">
            {tournaments.map((tourn) => (
              <div className="card" key={tourn.id}>
                <div style={{fontWeight: 900, fontSize: 18}}>{tourn.name}</div>
                <div className="muted" style={{marginTop: 6, fontSize: 13}}>
                  {tr.teamsCount}: <b>{tourn.teams_count}</b> • {tr.playersPerTeam}: <b>{tourn.players_per_team}</b>
                </div>

                <div className="sep" />

                <div style={{display:"flex", flexWrap:"wrap", gap:10}}>
                  <button className="btn" onClick={() => runDraw(tourn)} disabled={loading || tourn.draw_done}>
                    {tr.draw}
                  </button>
                  <button className="btn secondary" onClick={() => toggleRegistration(tourn.id, !tourn.registration_open)} disabled={loading || tourn.draw_done}>
                    {tourn.registration_open ? (lang==="ar" ? "إغلاق التسجيل" : "Close registration") : (lang==="ar" ? "فتح التسجيل" : "Open registration")}
                  </button>
                  <a className="btn secondary" href={`/t/${tourn.id}?lang=${lang}`} target="_blank" rel="noreferrer">
                    {lang==="ar" ? "فتح صفحة البطولة" : "Open tournament page"}
                  </a>
                </div>

                <div className="sep" />
                <div className="muted" style={{fontSize: 12}}>
                  ID: {tourn.id}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
