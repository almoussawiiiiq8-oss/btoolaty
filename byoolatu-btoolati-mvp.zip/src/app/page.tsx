import Link from "next/link";
import Nav from "@/components/Nav";
import { supabase } from "@/lib/supabase";
import { getLang, t } from "@/lib/i18n";
import type { Tournament } from "@/lib/types";

export default async function Home({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  const lang = getLang(searchParams);
  const tr = t(lang);

  const { data, error } = await supabase
    .from("tournaments")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(50);

  const tournaments = (data ?? []) as Tournament[];

  return (
    <div className="container">
      <Nav />
      <h1 className="h1">{tr.upcoming}</h1>
      <p className="sub">{lang === "ar"
        ? "سجّل في البطولة، وبعدها الأدمن يسوي القرعة وتظهر النتائج هنا."
        : "Register for a tournament. Admin runs the draw and results show here."}
      </p>

      {error && (
        <div className="card">
          <b>{tr.error}</b>
          <div className="muted" style={{marginTop: 6}}>{error.message}</div>
        </div>
      )}

      <div className="grid">
        {tournaments.map((tourn) => (
          <div className="card" key={tourn.id}>
            <div style={{display:"flex", justifyContent:"space-between", gap:10, alignItems:"start"}}>
              <div>
                <div style={{fontWeight: 900, fontSize: 18}}>{tourn.name}</div>
                <div className="muted" style={{marginTop: 6, fontSize: 13}}>
                  {(tourn.days_text ?? "").trim() ? `${tr.days}: ${tourn.days_text}` : ""}
                  {(tourn.time_text ?? "").trim() ? ` • ${tr.time}: ${tourn.time_text}` : ""}
                </div>
              </div>
              <div style={{display:"flex", flexDirection:"column", gap:8, alignItems:"end"}}>
                <span className="badge">
                  {tourn.registration_open ? tr.open : tr.closed}
                </span>
                <span className="badge" style={{background: tourn.draw_done ? "rgba(193,138,99,.18)" : "rgba(95,183,174,.14)"}}>
                  {tourn.draw_done ? tr.drawDone : tr.notDrawn}
                </span>
              </div>
            </div>

            <div className="sep" />

            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:10}}>
              <div className="muted" style={{fontSize: 13}}>
                {tr.teamsCount}: <b>{tourn.teams_count}</b> • {tr.playersPerTeam}: <b>{tourn.players_per_team}</b>
              </div>
              <Link className="btn" href={`/t/${tourn.id}?lang=${lang}`}>{tr.view}</Link>
            </div>
          </div>
        ))}
      </div>

      {!tournaments.length && !error && (
        <div className="card">
          <b>{lang === "ar" ? "لا توجد بطولات حالياً" : "No tournaments yet"}</b>
          <div className="muted" style={{marginTop: 6}}>
            {lang === "ar" ? "اذهب للأدمن وأنشئ أول بطولة." : "Go to Admin and create the first tournament."}
          </div>
        </div>
      )}
    </div>
  );
}
